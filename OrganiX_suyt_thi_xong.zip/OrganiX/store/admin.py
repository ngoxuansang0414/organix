from django.contrib import admin
from store.models.categories import Category
from store.models.orders import Order, OrderItem
from store.models.products import Product
from store.models.description import Description
from store.models.carts import Cart
from store.models.reviewrating import ReviewRating
# Register your models here.
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'slug']

class OrderAdmin(admin.ModelAdmin):
    list_display = ['tracking_no', 'name', 'total_price', 'payment_method','created_at', 'updated_at', 'status']
    list_filter = ['account', 'status']
    search_fields = ['account', 'address', 'phone']

class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['order', 'product', 'price', 'quantity']
    
class ProductAdmin(admin.ModelAdmin):
    list_display = 	['name', 'original_price', 'sale_price', 'category', 'image']
    list_filter = ['category']
    search_fields = ['name']

class DescriptionAdmin(admin.ModelAdmin):
    list_display = ['product','certification', 'origin', 'uses', 'instructions_for_use', 'preserving_instruction','expiry']

class CartAdmin(admin.ModelAdmin):
    list_display = ['account', 'product', 'product_qty', 'created_at']

class ReviewRatingAdmin(admin.ModelAdmin):
    list_display = ['product', 'user', 'rating', 'status']



admin.site.register(Category, CategoryAdmin)
admin.site.register(Order, OrderAdmin)
admin.site.register(Product, ProductAdmin)
admin.site.register(Cart, CartAdmin)
admin.site.register(Description, DescriptionAdmin)
admin.site.register(OrderItem, OrderItemAdmin)
admin.site.register(ReviewRating, ReviewRatingAdmin)


